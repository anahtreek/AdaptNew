import Child from './searchbar.jsx';

module.exports = Child;
